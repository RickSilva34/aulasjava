public class MainAnimal {
    public static void main(String[] args) {
        Animal cachorro = new Cachorro();
        Animal gato = new Gato();

        cachorro.emitirSom();
        cachorro.caminhar();
        
        gato.emitirSom();
        gato.caminhar();
    }
}