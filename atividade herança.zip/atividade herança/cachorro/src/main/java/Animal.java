public abstract class Animal {
    public abstract void emitirSom();
    public void caminhar() {
        System.out.println("O animal está caminhando.");
    }
}
