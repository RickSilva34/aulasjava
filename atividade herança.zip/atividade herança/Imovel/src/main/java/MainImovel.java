import java.util.Scanner;

public class MainImovel {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite 1 para imóvel novo e 2 para imóvel velho:");
        int tipo = scanner.nextInt();

        Imovel imovel = new Imovel(300000); // Valor base do imóvel
        boolean novo = tipo == 1;

        double valorFinal = imovel.calcularValorFinal(novo);
        System.out.println("Valor final do imóvel: R$ " + valorFinal);
    }
}
