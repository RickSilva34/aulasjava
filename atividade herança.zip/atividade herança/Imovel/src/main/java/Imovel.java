import java.util.Scanner;

public class Imovel {
    private double valorBase;
    
    public Imovel(double valorBase) {
        this.valorBase = valorBase;
    }

    public double calcularValorFinal(boolean novo) {
        return novo ? valorBase : valorBase * 0.8; // Desconto de 20% para imóveis velhos
    }
}
