import java.util.Scanner;

public class Ingresso {
    private double valor;
    
    public Ingresso(double valor) {
        this.valor = valor;
    }

    public double getValor() {
        return valor;
    }

    public void imprimirDetalhes() {
        System.out.println("Tipo de ingresso: Normal");
        System.out.println("Valor: R$ " + valor);
    }
}
