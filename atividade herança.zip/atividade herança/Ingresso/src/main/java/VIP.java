public class VIP extends Ingresso {
    private String tipoCamarote;

    public VIP(double valor, String tipoCamarote) {
        super(valor);
        this.tipoCamarote = tipoCamarote;
    }

    @Override
    public void imprimirDetalhes() {
        System.out.println("Tipo de ingresso: VIP");
        System.out.println("Camarote: " + tipoCamarote);
        System.out.println("Valor: R$ " + getValor());
    }
}
