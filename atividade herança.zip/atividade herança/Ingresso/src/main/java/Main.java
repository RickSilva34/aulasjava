import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite 1 para ingresso normal e 2 para VIP:");
        int tipo = scanner.nextInt();
        
        if (tipo == 1) {
            Ingresso ingresso = new Ingresso(100);
            ingresso.imprimirDetalhes();
        } else if (tipo == 2) {
            System.out.println("Digite 1 para camarote superior e 2 para camarote inferior:");
            int camarote = scanner.nextInt();
            String tipoCamarote = camarote == 1 ? "Superior" : "Inferior";
            VIP ingressoVIP = new VIP(200, tipoCamarote);
            ingressoVIP.imprimirDetalhes();
        } else {
            System.out.println("Opção inválida.");
        }
    }
}
