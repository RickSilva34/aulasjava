/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
public class Main {
    public static void main(String[] args) {
        AssistenteAdministrativo assistente = new AssistenteAdministrativo(1, "Joel Embiid");
        Tecnico tecnico = new Tecnico(2, "Paul George");

        assistente.imprimirInformacoes();
        tecnico.imprimirInformacoes();
    }
}
