public class pessoas {
   private int matricula;
    private String nome;

    public pessoas(int matricula, String nome) {
        this.matricula = matricula;
        this.nome = nome;
    }

    public int getMatricula() {
        return matricula;
    }

    public String getNome() {
        return nome;
    }

    public void imprimirInformacoes() {
        System.out.println("Matrícula: " + matricula + ", Nome: " + nome);
    }
}
