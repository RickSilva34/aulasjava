public class Pobre extends ClasseSocial {
    @Override
    public String tipo() {
        return "Classe Pobre";
    }
}
