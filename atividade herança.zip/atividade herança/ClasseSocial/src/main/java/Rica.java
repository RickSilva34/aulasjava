public class Rica extends ClasseSocial {
    @Override
    public String tipo() {
        return "Classe Rica";
    }
}
