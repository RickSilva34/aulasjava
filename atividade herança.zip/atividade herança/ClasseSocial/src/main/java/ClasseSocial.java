public class ClasseSocial {
    public String tipo() {
        return "Classe Social";
    }
}
