public class Main {
    public static void main(String[] args) {
        ClasseSocial rica = new Rica();
        ClasseSocial pobre = new Pobre();
        ClasseSocial miseravel = new Miseravel();

        System.out.println(rica.tipo());
        System.out.println(pobre.tipo());
        System.out.println(miseravel.tipo());
    }
}
