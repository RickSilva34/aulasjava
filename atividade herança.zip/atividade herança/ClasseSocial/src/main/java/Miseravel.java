public class Miseravel extends ClasseSocial {
    @Override
    public String tipo() {
        return "Classe Miserável";
    }
}
